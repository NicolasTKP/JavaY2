package com.mycompany.JavaY2;

public class Login {
}
