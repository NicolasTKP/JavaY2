/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.JavaY2;

/**
 *
 * @author acer
 */
public class JavaY2 {

    public static void main(String[] args) {
        Sale sale = new Sale("orange", "001", 30, 300);
        Sale sale2 = new Sale();
        System.out.println();
    }


}
