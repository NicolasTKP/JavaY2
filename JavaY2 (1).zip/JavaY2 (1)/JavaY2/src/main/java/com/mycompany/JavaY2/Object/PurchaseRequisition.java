package com.mycompany.JavaY2.Object;

import com.mycompany.JavaY2.PM.Services.Helper;
import com.mycompany.JavaY2.PM.Services.IEntity;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class PurchaseRequisition extends IEntity<PurchaseRequisition> {
    private String request_id;
    private String group_id;
    private String user_id;
    private String quantity;
    private String request_date;
    private String required_date;
    private OrderStatus status;

    public String getRequest_id() {
        return request_id;
    }

    public void setRequest_id(String request_id) {
        this.request_id = request_id;
    }

    public String getGroup_id() {
        return group_id;
    }

    public void setGroup_id(String group_id) {
        this.group_id = group_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getRequest_date() {
        return request_date;
    }

    public void setRequest_date(String request_date) {
        this.request_date = request_date;
    }

    public String getRequired_date() {
        return required_date;
    }

    public void setRequired_date(String required_date) {
        this.required_date = required_date;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    @Override
    public String toRecord() {
        return null;
    }

    @Override
    public PurchaseRequisition fromRecord(String record) {
        String[] split = Helper.split(record);
        PurchaseRequisition purchaseRequisition = new PurchaseRequisition();
        purchaseRequisition.setRequest_id(split[0]);
        purchaseRequisition.setGroup_id(split[1]);
        purchaseRequisition.setUser_id(split[2]);
        purchaseRequisition.setQuantity(split[3]);
        purchaseRequisition.setRequest_date(split[4]);
        purchaseRequisition.setRequired_date(split[5]);
        purchaseRequisition.setStatus(OrderStatus.valueOf(split[6]));
        return purchaseRequisition;
    }

    @Override
    public Object[] toObject() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMyyyy");
        return Helper.toObject(request_id, group_id, user_id, quantity, LocalDate.parse(request_date, formatter).toString(), LocalDate.parse(required_date, formatter).toString(), status.name());
    }

    public static String columns() {
        return Helper.createRecord(
                "request_id",
                "group_id",
                "user_id",
                "quantity",
                "request_date",
                "required_date",
                "status"
        );
    }
}
