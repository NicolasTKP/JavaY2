package com.mycompany.JavaY2.Object;

import com.mycompany.JavaY2.PM.Services.Helper;
import com.mycompany.JavaY2.PM.Services.IEntity;

public class Item extends IEntity<Item> {
    private String item_id;
    private String item_name;
    private String stock_price;
    private String sales_per_day;
    private String ordering_lead_time;
    private String safety_level;
    private String supplier_id;
    private String group_id;

    public String getItem_id() {
        return item_id;
    }

    public void setItem_id(String item_id) {
        this.item_id = item_id;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public String getStock_price() {
        return stock_price;
    }

    public void setStock_price(String stock_price) {
        this.stock_price = stock_price;
    }

    public String getSales_per_day() {
        return sales_per_day;
    }

    public void setSales_per_day(String sales_per_day) {
        this.sales_per_day = sales_per_day;
    }

    public String getOrdering_lead_time() {
        return ordering_lead_time;
    }

    public void setOrdering_lead_time(String ordering_lead_time) {
        this.ordering_lead_time = ordering_lead_time;
    }

    public String getSafety_level() {
        return safety_level;
    }

    public void setSafety_level(String safety_level) {
        this.safety_level = safety_level;
    }

    public String getSupplier_id() {
        return supplier_id;
    }

    public void setSupplier_id(String supplier_id) {
        this.supplier_id = supplier_id;
    }

    public String getGroup_id() {
        return group_id;
    }

    public void setGroup_id(String group_id) {
        this.group_id = group_id;
    }

    @Override
    public String toRecord() {
        return null;
    }

    @Override
    public Item fromRecord(String record) {
        String[] split = Helper.split(record);
        Item item = new Item();
        item.setItem_id(split[0]);
        item.setItem_name(split[1]);
        item.setStock_price(split[2]);
        item.setSales_per_day(split[3]);
        item.setOrdering_lead_time(split[4]);
        item.setSafety_level(split[5]);
        item.setSupplier_id(split[6]);
        item.setGroup_id(split[7]);
        return item;
    }

    @Override
    public Object[] toObject() {
        return Helper.toObject(
                item_id,
                item_name,
                stock_price,
                sales_per_day,
                ordering_lead_time,
                safety_level,
                supplier_id,
                group_id
        );
    }

    public static String columns() {
        return Helper.createRecord(
                "item_id",
                "item_name",
                "stock_price",
                "sales_per_day",
                "ordering_lead_time",
                "safety_level",
                "supplier_id",
                "group_id"
        );
    }
}
