/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.JavaY2.Class;
import javax.swing.*;

public class PurchaseManagerGUI {
    public static void main(string[] args){
        
    }

    private static class string {

        public string() {
        }
    }
    
}
