package com.mycompany.JavaY2.PM.Services;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class FileService implements IFileService {
    private final Path filePath;
    private final String fileColumns;

    public FileService(String fileName, String fileProperties) {
        this.filePath = Paths.get(AppSettings.FILE_BASE_PATH).resolve(fileName);
        this.fileColumns = fileProperties;
        createIfNotExist();
    }

    @Override
    public void add(String record) {
//        String existingRecord = getById(record.split("\\|")[0]);
//        if (existingRecord != null) throw new RuntimeException("Record Already Exists");
        try (BufferedWriter writer = Files.newBufferedWriter(filePath, StandardOpenOption.APPEND)) {
            writer.write(record);
            writer.newLine();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void addRange(List<String> records, OpenOption option) {
        try (BufferedWriter writer = Files.newBufferedWriter(filePath, option)) {
            for (String record : records) {
                writer.write(record);
                writer.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean deleteById(String id) {
        boolean deleted = false;
        List<String> filteredLines = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(id)) {
                    deleted = true;
                    continue;
                }
                filteredLines.add(line);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        addRange(filteredLines, StandardOpenOption.TRUNCATE_EXISTING);
        return deleted;
    }

    @Override
    public boolean updateById(String columnName, String id, String value) {
        boolean updated = false;
        List<String> updatedLines = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line = reader.readLine();
            String[] columnNames = Helper.split(line);
            int index = 0;
            for (String column : columnNames) {
                if (column.equalsIgnoreCase(columnName)) {
                    break;
                }
                index++;
            }
            updatedLines.add(line);
            while ((line = reader.readLine()) != null) {
                String[] record = Helper.split(line);
                String recordId = record[0];
                if (!updated && recordId.equals(id)) {
                    record[index] = value;
                    String updatedRecord = String.join("|", record);
                    updatedLines.add(updatedRecord);
                    updated = true;
                } else {
                    updatedLines.add(line);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        addRange(updatedLines, StandardOpenOption.TRUNCATE_EXISTING);
        return updated;
    }

    @Override
    public String getById(String id) {
        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(id)) {
                    return line;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    @Override
    public List<String> getAll() {
        List<String> records = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line;
            while ((line = reader.readLine()) != null) {
                records.add(line);
            }
            records.removeFirst();
            return records;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<String> findWhere(String columnName, String value) {
        List<String> matchedRecords = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line = reader.readLine();
            String[] columnNames = Helper.split(line);
            int index = 0;
            for (String column : columnNames) {
                if (column.equalsIgnoreCase(columnName)) {
                    break;
                }
                index++;
            }
            while ((line = reader.readLine()) != null) {
                String[] record = Helper.split(line);
                String columnValue = record[index];
                if (columnValue.equals(value)) {
                    matchedRecords.add(line);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return matchedRecords;
    }

    @Override
    public String findSingleWhere(String columnName, String value) {
        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line = reader.readLine();
            String[] columnNames = Helper.split(line);
            int index = 0;
            for (String column : columnNames) {
                if (column.trim().equalsIgnoreCase(columnName)) {
                    break;
                }
                index++;
            }
            while ((line = reader.readLine()) != null) {
                String[] record = Helper.split(line);
                String columnValue = record[index];
                if (columnValue.equals(value)) {
                    return line;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    private void createIfNotExist() {
        try {
            if (Files.notExists(filePath)) {
                Files.createFile(filePath);
                add(fileColumns);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}

