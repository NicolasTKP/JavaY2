package com.mycompany.JavaY2.PM.Services;

public class AppSettings {
    public static final String FILE_BASE_PATH = "C:\\Users\\remem\\Desktop\\Javaaa\\JavaY2\\JavaY2\\src\\main\\java\\com\\mycompany\\JavaY2\\TextFile\\";
}
