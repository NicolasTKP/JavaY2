package com.mycompany.JavaY2.Object;

import com.mycompany.JavaY2.PM.Services.Helper;
import com.mycompany.JavaY2.PM.Services.IEntity;

public class Supplier extends IEntity<Supplier> {
    private String supplier_id;
    private String supplier_name;
    private String address;
    private String contact;
    private String supply_items;
    private String payment_term;

    public String getSupplier_id() {
        return supplier_id;
    }

    public void setSupplier_id(String supplier_id) {
        this.supplier_id = supplier_id;
    }

    public String getSupplier_name() {
        return supplier_name;
    }

    public void setSupplier_name(String supplier_name) {
        this.supplier_name = supplier_name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getSupply_items() {
        return supply_items;
    }

    public void setSupply_items(String supply_items) {
        this.supply_items = supply_items;
    }

    public String getPayment_term() {
        return payment_term;
    }

    public void setPayment_term(String payment_term) {
        this.payment_term = payment_term;
    }

    @Override
    public String toRecord() {
        return null;
    }

    @Override
    public Supplier fromRecord(String record) {
        String[] split = Helper.split(record);
        Supplier supplier = new Supplier();
        supplier.setSupplier_id(split[0]);
        supplier.setSupplier_name(split[1]);
        supplier.setAddress(split[2]);
        supplier.setContact(split[3]);
        supplier.setSupply_items(split[4]);
        supplier.setPayment_term(split[5]);
        return supplier;
    }

    @Override
    public Object[] toObject() {
        return Helper.toObject(
                supplier_id,
                supplier_name,
                address,
                contact,
                supply_items,
                payment_term
        );
    }

    public static String columns() {
        return Helper.createRecord(
                "supplier_id",
                "supplier_name",
                "address",
                "contact",
                "supply_items",
                "payment_term"
        );
    }
}
