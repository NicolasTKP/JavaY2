package com.mycompany.JavaY2.PM.Repositories;

import com.mycompany.JavaY2.Object.Supplier;
import com.mycompany.JavaY2.PM.Services.FileCrudRepository;
import com.mycompany.JavaY2.PM.Services.FileService;

public class SupplierRepository extends FileCrudRepository<Supplier> {
    public SupplierRepository() {
        super(new FileService("suppliers", ""), Supplier.class);
    }
}
