package com.mycompany.JavaY2.PM.UI;


import com.mycompany.JavaY2.Object.*;
import com.mycompany.JavaY2.PM.Repositories.*;
import com.mycompany.JavaY2.PM.Services.Helper;
import com.mycompany.JavaY2.PM.Services.IEntity;
import com.mycompany.JavaY2.PM.UIComponents.ActionButton;
import com.mycompany.JavaY2.PM.UIComponents.MyDialog;
import com.mycompany.JavaY2.PM.UIComponents.MyLabel;
import com.mycompany.JavaY2.PM.UIComponents.MyTable;
import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PMDashboard extends JFrame {

    private JPanel mainPanel;
    private JButton purchaseOrdersBtn;
    private JButton itemManagementBtn;
    private JButton supplierManagementBtn;
    private JButton purchaseRequisitionsBtn;
    private JButton generatePOBtn;
    private ICrudRepository<PurchaseOrder> poRepository;
    private ICrudRepository<PurchaseRequisition> prRepository;
    private ICrudRepository<Item> itemRepository;
    private ICrudRepository<Supplier> supplierRepository;


    public PMDashboard() {
        poRepository = new PORepository();
        prRepository = new PRRepository();
        itemRepository = new ItemRepository();
        supplierRepository = new SupplierRepository();
        setTitle("OWSB Dashboard");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new BorderLayout());

        // Left sidebar with menu buttons
        JPanel sidebar = new JPanel();
        sidebar.setBackground(new Color(40, 44, 52));
        sidebar.setLayout(new GridLayout(0, 1, 0, 10));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 10));
        initMainButtons(sidebar);
        addListeners();

        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(new Color(30, 33, 36));
        topBar.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel title = new JLabel("Welcome to OWSB");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));

        JPanel topRightButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        topRightButtons.setOpaque(false);


        topBar.add(title, BorderLayout.NORTH);
        topBar.add(topRightButtons, BorderLayout.EAST);

        // Main content panel placeholder
        mainPanel = new JPanel();
        mainPanel.setBackground(new Color(60, 63, 65));
        mainPanel.setLayout(new BorderLayout());

        JLabel contentLabel = new JLabel("Select an option from the menu", SwingConstants.CENTER);
        contentLabel.setForeground(Color.LIGHT_GRAY);
        contentLabel.setFont(new Font("Segoe UI", Font.PLAIN, 22));
        mainPanel.add(contentLabel, BorderLayout.CENTER);

        // Layout everything
        add(topBar, BorderLayout.NORTH);
        add(sidebar, BorderLayout.WEST);
        add(mainPanel, BorderLayout.CENTER);
    }

    private JButton createMenuButton(String label) {
        JButton btn = new JButton(label);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setBackground(new Color(60, 63, 65));
        btn.setForeground(Color.WHITE);
        btn.setHorizontalAlignment(SwingConstants.CENTER);
        btn.setPreferredSize(new Dimension(250, 40));
        return btn;
    }

    private void initMainButtons(JPanel sidebar) {

        purchaseOrdersBtn = createMenuButton("Purchase Orders");
        itemManagementBtn = createMenuButton("Items");
        supplierManagementBtn = createMenuButton("Suppliers");
        purchaseRequisitionsBtn = createMenuButton("Purchase Requisitions");
        generatePOBtn = createMenuButton("Generate Purchase Order");


        sidebar.add(itemManagementBtn, "growx");
        sidebar.add(supplierManagementBtn, "growx");
        sidebar.add(purchaseRequisitionsBtn, "growx");
        sidebar.add(generatePOBtn, "growx");
        sidebar.add(purchaseOrdersBtn, "growx");
    }

    private void addListeners() {


        purchaseOrdersBtn.addActionListener(e -> {
            List<PurchaseOrder> all = poRepository.getAll();
            setForm(all, PurchaseOrder.columns());
        });
        itemManagementBtn.addActionListener(e -> {
            List<Item> all = itemRepository.getAll();
            setForm(all, Item.columns());
        });
        supplierManagementBtn.addActionListener(e -> {
            List<Supplier> all = supplierRepository.getAll();
            setForm(all, Supplier.columns());
        });
        purchaseRequisitionsBtn.addActionListener(e -> {
            List<PurchaseRequisition> all = prRepository.getAll();
            setForm(all, PurchaseRequisition.columns());
        });
        generatePOBtn.addActionListener(e -> {
            setFormPO();
        });
    }

    private <T extends IEntity<T>> void setForm(List<T> list, String columns) {
        Object[][] dataTable = Helper.toDataTable(list);
        String[] tableColumns = Helper.split(columns);
        MyTable table = new MyTable(dataTable, tableColumns);
        mainPanel.removeAll();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(table, BorderLayout.CENTER);
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    private void setFormPO() {
        MyDialog dialog = new MyDialog(this, "Add Purchase Order", 9);
        dialog.setHeight(700);
        MyLabel order_id_label = new MyLabel("Order Id");
        MyLabel request_id_label = new MyLabel("Request Id");
        MyLabel item_id_label = new MyLabel("Item Id");
        MyLabel user_id_label = new MyLabel("User Id");
        MyLabel quantity_label = new MyLabel("Quantity");
        MyLabel unit_price_label = new MyLabel("Unit Price");
        MyLabel amount_label = new MyLabel("Amount");
        MyLabel supplier_id_label = new MyLabel("Supplier Id");
        MyLabel order_date_label = new MyLabel("Order Date");
//        MyLabel order_status_label = new MyLabel("Order Status");
        JTextField order_id_field = new JTextField();
        JTextField request_id_field = new JTextField();
        JTextField item_id_field = new JTextField();
        JTextField user_id_field = new JTextField();
        JTextField quantity_field = new JTextField();
        JTextField unit_price_field = new JTextField();
        JTextField amount_field = new JTextField();
        JTextField supplier_id_field = new JTextField();
        JTextField order_date_field = new JTextField();
        dialog.add(order_id_label);
        dialog.add(order_id_field);
        dialog.add(request_id_label);
        dialog.add(request_id_field);
        dialog.add(item_id_label);
        dialog.add(item_id_field);
        dialog.add(user_id_label);
        dialog.add(user_id_field);
        dialog.add(quantity_label);
        dialog.add(quantity_field);
        dialog.add(unit_price_label);
        dialog.add(unit_price_field);
        dialog.add(amount_label);
        dialog.add(amount_field);
        dialog.add(supplier_id_label);
        dialog.add(supplier_id_field);
        dialog.add(order_date_label);
        dialog.add(order_date_field);
        dialog.showDialog(e -> {
            PurchaseOrder po = new PurchaseOrder();
            po.setOrder_id(order_id_field.getText().trim());
            po.setRequest_id(request_id_field.getText().trim());
            po.setItem_id(item_id_field.getText().trim());
            po.setUser_id(user_id_field.getText().trim());
            po.setQuantity(quantity_field.getText().trim());
            po.setUnit_price(unit_price_field.getText().trim());
            po.setAmount(amount_field.getText().trim());
            po.setSupplier_id(supplier_id_field.getText().trim());
            po.setOrder_date(order_date_field.getText().trim());
            po.setOrder_status(OrderStatus.Pending);
            poRepository.add(po);
            dialog.dispose();
        });


//        mainPanel.removeAll();
//        mainPanel.setLayout(new BorderLayout());
//        mainPanel.add(panel, BorderLayout.CENTER);
//        mainPanel.revalidate();
//        mainPanel.repaint();
    }

    public static void main(String[] args) {


        SwingUtilities.invokeLater(() -> {
            PMDashboard ui = new PMDashboard();
            ui.setVisible(true);
        });
    }
}



