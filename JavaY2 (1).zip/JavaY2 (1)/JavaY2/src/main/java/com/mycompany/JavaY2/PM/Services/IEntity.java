package com.mycompany.JavaY2.PM.Services;

import java.util.UUID;

public abstract class IEntity<T> {


    public abstract String toRecord();

    public abstract T fromRecord(String record);

    public abstract Object[] toObject();

}
