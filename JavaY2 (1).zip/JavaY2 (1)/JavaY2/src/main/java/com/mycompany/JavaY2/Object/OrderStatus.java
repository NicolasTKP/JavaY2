package com.mycompany.JavaY2.Object;

public enum OrderStatus {
    Pending,
    Approved,
    Rejected
}
