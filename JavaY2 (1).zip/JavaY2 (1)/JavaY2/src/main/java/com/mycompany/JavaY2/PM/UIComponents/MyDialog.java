package com.mycompany.JavaY2.PM.UIComponents;

import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;


public class MyDialog extends JDialog {

    public MyDialog(Frame owner, String title, int componentCount) {
        super(owner, title, true);
        String rowConstraints = "[]5[]15".repeat(componentCount) + "[fill, grow]0[]10";
        setMinimumSize(new Dimension(400, 400));
        setLocationRelativeTo(this);
        setLayout(new MigLayout("wrap 1", "[fill, grow]", rowConstraints));
        getContentPane().setBackground(Color.darkGray);


    }

    public void setHeight(int height) {
        setMinimumSize(new Dimension(400, height));
    }

    public void showDialog(ActionListener onSubmit) {
        ActionButton submitBtn = new ActionButton("Submit");
        submitBtn.addActionListener(onSubmit);
        add(new JLabel());
        add(submitBtn);
        setVisible(true);
    }
}
