package com.mycompany.JavaY2.PM.Services;

import java.util.List;

public class Helper {
    public static String createRecord(String... params) {
        return String.join("|", params);
    }

    public static String[] split(String record) {
        return record.split("\\|");
    }

    public static Object[] toObject(String... params) {
        Object[] obj = new Object[params.length];
        for (int i = 0; i < params.length; i++) {
            obj[i] = params[i];
        }
        return obj;
    }

    public static <T extends IEntity<T>> Object[][] toDataTable(List<T> list) {
        return list.stream().map(IEntity::toObject)
                .toArray(Object[][]::new);
    }
}
