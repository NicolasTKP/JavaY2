package com.mycompany.JavaY2.PM.Services;


import com.mycompany.JavaY2.PM.Repositories.ICrudRepository;

import java.util.List;

public class FileCrudRepository<TEntity extends IEntity<TEntity>> implements ICrudRepository<TEntity> {
    protected final IFileService fileService;
    private final Class<TEntity> entityClass;

    public FileCrudRepository(IFileService fileService, Class<TEntity> entityClass) {
        this.fileService = fileService;
        this.entityClass = entityClass;
    }

    @Override
    public void add(TEntity record) {
        fileService.add(record.toRecord());
    }

    @Override
    public TEntity getById(String id) {
        try {
            String record = fileService.getById(id);
            if (record == null) {
                return null;
            }
            TEntity entity = entityClass.getDeclaredConstructor().newInstance();
            return entity.fromRecord(record);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<TEntity> getAll() {
        try {
            List<String> records = fileService.getAll();
            TEntity entity = entityClass.getDeclaredConstructor().newInstance();
            return records.stream().map(entity::fromRecord).toList();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean updateById(String columnName, String id, String value) {
        return fileService.updateById(columnName, id, value);
    }

    @Override
    public boolean deleteById(String id) {
        return fileService.deleteById(id);
    }

    @Override
    public List<TEntity> findWhere(String columnName, String value) {
        try {
            List<String> records = fileService.findWhere(columnName, value);
            TEntity entity = entityClass.getDeclaredConstructor().newInstance();
            return records.stream().map(entity::fromRecord).toList();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public TEntity findSingleWhere(String columnName, String value) {
        try {
            String record = fileService.findSingleWhere(columnName, value);
            if (record == null) {
                return null;
            }
            TEntity entity = entityClass.getDeclaredConstructor().newInstance();
            return entity.fromRecord(record);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
