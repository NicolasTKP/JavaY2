package com.mycompany.JavaY2.PM.UIComponents;


import com.mycompany.JavaY2.PM.Services.IEntity;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MyTable extends JScrollPane {
    private JTable jTable;

    public MyTable(Object[][] data, String[] columnNames) {

        jTable = new JTable(new DefaultTableModel(data, columnNames));
        jTable.setRowHeight(30);
        jTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        jTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        jTable.setShowGrid(true); // Enable grid lines
        jTable.setGridColor(Color.LIGHT_GRAY);
        setViewportView(jTable);
        setVisible(true);
    }

    public int getSelectedRow() {
        int selectedRow = jTable.getSelectedRow();
        if (selectedRow != -1) {
            return selectedRow;
        }
        JOptionPane.showMessageDialog(this, "Please select a row.");
        return -1;
    }

    private void updateModel(DefaultTableModel model) {
        jTable.setModel(model);
        jTable.updateUI();
    }

    public <T extends IEntity<T>> void addRow(T raw) {
        DefaultTableModel model = (DefaultTableModel) jTable.getModel();
        model.addRow(raw.toObject());
        updateModel(model);
    }

    public <T extends IEntity<T>> void removeRow(int index) {
        DefaultTableModel model = (DefaultTableModel) jTable.getModel();
        model.removeRow(index);
        updateModel(model);
    }

    public <T extends IEntity<T>> void setModel(List<T> list) {
        DefaultTableModel model = (DefaultTableModel) jTable.getModel();
        jTable.removeAll();
        for (var item : list) {
            model.addRow(item.toObject());
        }
        jTable.setModel(model);
        jTable.updateUI();
    }
}
