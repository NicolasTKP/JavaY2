package com.mycompany.JavaY2.PM.Repositories;

import com.mycompany.JavaY2.Object.PurchaseOrder;
import com.mycompany.JavaY2.PM.Services.FileCrudRepository;
import com.mycompany.JavaY2.PM.Services.FileService;
import com.mycompany.JavaY2.PM.Services.IFileService;

public class PORepository extends FileCrudRepository<PurchaseOrder> {
    public PORepository() {
        super(new FileService("purchase_orders",PurchaseOrder.columns()), PurchaseOrder.class);
    }
}
