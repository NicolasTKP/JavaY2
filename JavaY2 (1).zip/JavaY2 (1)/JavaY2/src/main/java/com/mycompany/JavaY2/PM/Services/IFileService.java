package com.mycompany.JavaY2.PM.Services;

import java.nio.file.OpenOption;
import java.util.List;

public interface IFileService {
    void add(String record);

    void addRange(List<String> records, OpenOption option);

    boolean deleteById(String id);

    boolean updateById(String columnName, String id, String value);

    String getById(String id);

    List<String> getAll();

    List<String> findWhere(String columnName, String value);

    String findSingleWhere(String columnName, String value);
}
