package com.mycompany.JavaY2.PM.Repositories;

import com.mycompany.JavaY2.PM.Services.IEntity;

import java.util.List;

public interface ICrudRepository<TEntity extends IEntity<TEntity>> {

    void add(TEntity record);

    TEntity getById(String id);

    List<TEntity> getAll();

    boolean updateById(String columnName, String id, String value);

    boolean deleteById(String id);

    List<TEntity> findWhere(String columnName, String value);

    TEntity findSingleWhere(String columnName, String value);
}
