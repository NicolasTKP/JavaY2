package com.mycompany.JavaY2.PM.UIComponents;

import javax.swing.*;
import java.awt.*;

public class ActionButton extends JButton {

    public ActionButton(String text) {
        setText(text);
        setFont(new Font("Segoe UI", Font.BOLD, 15));
        setForeground(Color.WHITE);
        setBackground(new Color(70, 130, 180));
        setFocusPainted(false);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
    }
}
