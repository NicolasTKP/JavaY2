package com.mycompany.JavaY2.PM.Repositories;

import com.mycompany.JavaY2.Object.PurchaseRequisition;
import com.mycompany.JavaY2.PM.Services.FileCrudRepository;
import com.mycompany.JavaY2.PM.Services.FileService;

public class PRRepository extends FileCrudRepository<PurchaseRequisition> {
    public PRRepository() {
        super(new FileService("purchase_requisitions", ""), PurchaseRequisition.class);
    }
}
