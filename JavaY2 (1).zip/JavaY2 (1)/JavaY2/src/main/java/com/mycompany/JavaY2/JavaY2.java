/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.JavaY2;

/**
 *
 * @author acer
 */
public class JavaY2 {

    public static void main(String[] args) {
        System.out.println();
    }


}
