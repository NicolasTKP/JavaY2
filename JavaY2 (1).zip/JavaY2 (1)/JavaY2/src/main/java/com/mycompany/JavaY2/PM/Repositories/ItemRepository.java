package com.mycompany.JavaY2.PM.Repositories;

import com.mycompany.JavaY2.Object.Item;
import com.mycompany.JavaY2.PM.Services.FileCrudRepository;
import com.mycompany.JavaY2.PM.Services.FileService;

public class ItemRepository extends FileCrudRepository<Item> {
    public ItemRepository() {
        super(new FileService("items", ""), Item.class);
    }
}
