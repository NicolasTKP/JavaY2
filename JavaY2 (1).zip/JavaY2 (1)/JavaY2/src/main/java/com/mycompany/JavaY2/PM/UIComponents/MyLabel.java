package com.mycompany.JavaY2.PM.UIComponents;

import javax.swing.*;
import java.awt.*;

public class MyLabel extends JLabel {

    public MyLabel(String text) {
        super(text);
        setForeground(Color.white);
        setFont(new Font("Segoe UI", Font.PLAIN, 14));
    }
}
