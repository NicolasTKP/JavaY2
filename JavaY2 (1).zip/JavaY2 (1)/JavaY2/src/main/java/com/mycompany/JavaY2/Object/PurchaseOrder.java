package com.mycompany.JavaY2.Object;

import com.mycompany.JavaY2.PM.Services.Helper;
import com.mycompany.JavaY2.PM.Services.IEntity;

public class PurchaseOrder extends IEntity<PurchaseOrder> {
    private String order_id;
    private String request_id;
    private String item_id;
    private String user_id;
    private String quantity;
    private String unit_price;
    private String amount;
    private String supplier_id;
    private String order_date;
    private OrderStatus order_status;

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getRequest_id() {
        return request_id;
    }

    public void setRequest_id(String request_id) {
        this.request_id = request_id;
    }

    public String getItem_id() {
        return item_id;
    }

    public void setItem_id(String item_id) {
        this.item_id = item_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getUnit_price() {
        return unit_price;
    }

    public void setUnit_price(String unit_price) {
        this.unit_price = unit_price;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getSupplier_id() {
        return supplier_id;
    }

    public void setSupplier_id(String supplier_id) {
        this.supplier_id = supplier_id;
    }

    public String getOrder_date() {
        return order_date;
    }

    public void setOrder_date(String order_date) {
        this.order_date = order_date;
    }

    public OrderStatus getOrder_status() {
        return order_status;
    }

    public void setOrder_status(OrderStatus order_status) {
        this.order_status = order_status;
    }

    @Override
    public String toRecord() {
        return Helper.createRecord(
                order_id,
                request_id,
                item_id,
                user_id,
                quantity,
                unit_price,
                amount,
                supplier_id,
                order_date,
                order_status.name()
        );
    }

    @Override
    public PurchaseOrder fromRecord(String record) {
        String[] split = Helper.split(record);
        PurchaseOrder purchaseOrder = new PurchaseOrder();
        purchaseOrder.setOrder_id(split[0]);
        purchaseOrder.setRequest_id(split[1]);
        purchaseOrder.setItem_id(split[2]);
        purchaseOrder.setUser_id(split[3]);
        purchaseOrder.setQuantity(split[4]);
        purchaseOrder.setUnit_price(split[5]);
        purchaseOrder.setAmount(split[6]);
        purchaseOrder.setSupplier_id(split[7]);
        purchaseOrder.setOrder_date(split[8]);
        purchaseOrder.setOrder_status(OrderStatus.valueOf(split[9]));
        return purchaseOrder;
    }

    @Override
    public Object[] toObject() {
        return Helper.toObject(
                order_id,
                request_id,
                item_id,
                user_id,
                quantity,
                unit_price,
                amount,
                supplier_id,
                order_date,
                order_status.name());
    }

    public static String columns() {
        return Helper.createRecord(
                "order_id",
                "request_id",
                "item_id",
                "user_id",
                "quantity",
                "unit_price",
                "amount",
                "supplier_id",
                "order_date",
                "order_status"
        );
    }
}
